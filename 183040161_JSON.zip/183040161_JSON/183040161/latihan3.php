<!DOCTYPE html>
<html lang="en">
<head>
    <title>Latihan JSON</title>
</head>
<body>
    <script src="script.js"></script>
</body>
</html>