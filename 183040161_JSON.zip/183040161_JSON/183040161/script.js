let mahasiswa = {
    nama : "Anisa Al Fauziah",
    nrp : "183040161",
    email : "fauziah.183040161@mail.unpas.ac.id"
}

console.log(JSON.stringify(mahasiswa));